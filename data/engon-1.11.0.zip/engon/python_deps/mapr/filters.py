# copyright (c) 2018- polygoniq xyz s.r.o.

# Base classes for filters which can be used in a query against asset provider to get assets
# based on their parameters. For example one can use:
# - NumericParameterFilter("num:width", 0.0, 10.0) - assets with '0.0 <= "width" <= 10.0'
# - TextParameterFilter("text:country_of_origin", {"Czechia", "Poland"}) - assets containing
#   "country_of_origin" either "Czechia" or "Poland"
# The filters defined here provide the minimal functionality needed for filtering and can be used
# without 'bpy'. The filters in `engon.browser` are their more complex implementation based
# on 'bpy' with UI state and other functionality

import abc
import functools
import typing
import mathutils
import re
import math
from . import asset
from . import asset_data
from . import parameter_meta


class Filter:
    def __init__(self, name: str):
        self.name = name
        self.name_without_type = parameter_meta.remove_type_from_name(self.name)

    def filter_(self, asset_: asset.Asset) -> bool:
        """Decides if the 'asset' should be filtered.

        Returns True if asset passes the filter, False otherwise.
        NOTE: This should consider also filtering out assets which don't have any value of the
        corresponding parameter present.
        """
        raise NotImplementedError()

    def as_dict(self) -> dict:
        """Returns a dict entry representing this filter - {key: filter-parameters}.

        The 'key' has to be unique across all the filters! The self.name is mostly used
        for that as it is prefixed by the 'type:' based on the filter.
        """
        raise NotImplementedError()


class NumericParameterFilter(Filter):
    def __init__(self, name: str, range_start: float, range_end: float):
        super().__init__(name)
        self.range_start = range_start
        self.range_end = range_end

    def filter_(self, asset_: asset.Asset) -> bool:
        if self.name_without_type not in asset_.numeric_parameters:
            return False

        return (
            self.range_start <= asset_.numeric_parameters[self.name_without_type] <= self.range_end
        )

    def as_dict(self) -> dict:
        return {self.name: {"min": self.range_start, "max": self.range_end}}


class TagFilter(Filter):
    def __init__(self, name: str, include: bool = True):
        super().__init__(name)
        # If one instantiates the base TagFilter, they mean to filter by this tag, unless
        # 'include' is set to False - in that case assets with this tag are filtered out.
        self.include = include
        self.exclude = not include

    def filter_(self, asset_: asset.Asset) -> bool:
        has_tag = self.name_without_type in asset_.tags
        return has_tag != self.exclude

    def as_dict(self) -> dict[str, dict[str, bool]]:
        return {self.name: {"include": self.include, "exclude": self.exclude}}


class TextParameterFilter(Filter):
    def __init__(self, name: str, values: set[str]):
        super().__init__(name)
        self.values = values

    def filter_(self, asset_: asset.Asset) -> bool:
        value = asset_.text_parameters.get(self.name_without_type, None)
        if value is None:
            return False

        return value in self.values

    def as_dict(self) -> dict:
        return {self.name: list(self.values)}


class VectorComparator(abc.ABC):
    @abc.abstractmethod
    def compare(self, value: mathutils.Vector) -> bool:
        pass

    @abc.abstractmethod
    def as_dict(self) -> dict:
        """The dict representation of the comparator, has to be unique for each comparator type."""
        pass


DistanceFunction = typing.Callable[[mathutils.Vector, mathutils.Vector], float]
NamedDistanceFunction = tuple[DistanceFunction, str]


class VectorDistanceComparator(VectorComparator):
    """Compares distance of point to other point (represented as vectors) to a distance threshold.

    If the 'distance_function' is provided, then it is a tuple of the distance function and a name
    of the function. The name is used in `as_dict` representation of the comparator which is used
    for caching. Name needs to be unique otherwise cache can return incorrect results for queries
    that filter out different assets but have the same `as_dict` representation.
    """

    def __init__(
        self,
        value: mathutils.Vector,
        distance: float,
        distance_function: NamedDistanceFunction | None = None,
    ):
        self.value = value
        self.distance = distance
        if distance_function is None:
            self.distance_function = VectorDistanceComparator._euclidean_distance
            self.distance_function_name = "euclidean"
        else:
            self.distance_function = distance_function[0]
            self.distance_function_name = distance_function[1]

    def compare(self, value: mathutils.Vector) -> bool:
        if len(value) != len(self.value):
            raise ValueError("Vector length mismatch")

        return self.distance_function(value, self.value) <= self.distance

    def as_dict(self) -> dict:
        return {
            "value": tuple(self.value),
            "distance": self.distance,
            "function": self.distance_function_name,
        }

    @staticmethod
    def _euclidean_distance(a: mathutils.Vector, b: mathutils.Vector) -> float:
        return (a - b).length


class VectorLexicographicComparator(VectorComparator):
    """Compares vectors lexicographically, the min_ and max_ are inclusive"""

    def __init__(self, min_: mathutils.Vector, max_: mathutils.Vector):
        self.min_ = min_
        self.max_ = max_

    def compare(self, value: mathutils.Vector) -> bool:
        return tuple(self.min_) <= tuple(value) <= tuple(self.max_)

    def as_dict(self) -> dict:
        return {"min": tuple(self.min_), "max": tuple(self.max_), "method": "lexicographic"}


class VectorComponentWiseComparator(VectorComparator):
    """Compares vectors component-wise - each component separately, the min_ and max_ are inclusive"""

    def __init__(self, min_: mathutils.Vector, max_: mathutils.Vector):
        self.min_ = min_
        self.max_ = max_

    def compare(self, value: mathutils.Vector) -> bool:
        if len(value) != len(self.min_) != len(self.max_):
            raise ValueError("Vector length mismatch")

        # Use component wise comparison, the default comparison operators for vector compare lengths
        for i in range(len(value)):
            if not self.min_[i] <= value[i] <= self.max_[i]:
                return False

        return True

    def as_dict(self) -> dict:
        return {"min": tuple(self.min_), "max": tuple(self.max_), "method": "component-wise"}


class MapProjection(abc.ABC):
    """Projects from latitude and longitude to XY coordinates on a fixed-sized grid"""

    @property
    @abc.abstractmethod
    def max_x(self) -> int:
        pass

    @property
    @abc.abstractmethod
    def max_y(self) -> int:
        pass

    # due to rounding in the location data, we have repeated values, we can cache where possible
    @abc.abstractmethod
    def project(self, latitude: float, longitude: float) -> tuple[int, int]:
        """Projects latitude and longitude to XY coordinates on the grid"""
        pass

    @property
    @abc.abstractmethod
    def crop(self) -> tuple[int, int, int, int]:
        """Returns the crop of the map projection - top, bottom, left, right"""
        return (0, 0, 0, 0)


class MercatorProjection(MapProjection):
    """Implements 16x16 grid Mercator projection between 85S and 85N."""

    @property
    def max_x(self) -> int:
        return 16

    @property
    def max_y(self) -> int:
        return 16

    @property
    def crop(self) -> tuple[int, int, int, int]:
        """Returns the crop of the map projection - top, bottom, left, right"""
        return (0, 4, 0, 0)  # bottom - antarctica

    # due to rounding in the location data, we have repeated values, we can use caching
    @functools.cache
    def project_x(self, longitude: float) -> int:
        """Projects longitude to X coordinate on the grid."""
        if longitude < -180 or longitude > 180:
            longitude = max(-180, min(180, longitude))

        return int((longitude + 180) / 360 * self.max_x)

    # due to rounding in the location data, we have repeated values, we can use caching
    @functools.cache
    def project_y(self, latitude: float) -> int:
        """Projects latitude to Y coordinate on the grid."""
        if latitude < -85 or latitude > 85:
            latitude = max(-85, min(85, latitude))

        lat_rads = math.radians(latitude)
        return int(
            (1 - math.log(math.tan(lat_rads) + 1 / math.cos(lat_rads)) / math.pi) / 2 * self.max_y
        )

    def project(self, latitude: float, longitude: float) -> tuple[int, int]:
        """Projects latitude and longitude to XY coordinates on the grid.

        Implements Mercator projection, see https://en.wikipedia.org/wiki/Mercator_projection.
        The projection is clamped to +/-85 degrees latitude. Median is 0 degrees (greenwich).

        """

        return self.project_x(longitude), self.project_y(latitude)


class LocationParameterFilter(Filter):
    """Checks if the location contains at least one of the selected tiles"""

    map_projection = MercatorProjection()

    def __init__(
        self,
        name: str,
        selected_tiles: list[list[bool]],
    ):
        super().__init__(name)
        self.selected_tiles = selected_tiles

    def filter_(self, asset_: asset.Asset) -> bool:
        projection = LocationParameterFilter.map_projection
        asset_locations = asset_.location_parameters.get(self.name_without_type)

        if asset_locations is None:
            return False

        selected_tiles = self.selected_tiles
        for lat, lon in asset_locations:
            x, y = projection.project(lat, lon)
            if selected_tiles[y][x]:
                return True

        return False

    def as_dict(self) -> dict:
        return {self.name: self.selected_tiles}


class VectorParameterFilter(Filter):
    def __init__(
        self,
        name: str,
        comparator: VectorComparator,
    ):
        super().__init__(name)
        self.comparator = comparator

    def filter_(self, asset_: asset.Asset) -> bool:
        value = asset_.vector_parameters.get(self.name_without_type, None)
        if value is None:
            return False

        return self.comparator.compare(mathutils.Vector(value))

    def as_dict(self) -> dict:
        return {self.name: self.comparator.as_dict()}


class AssetTypesFilter(Filter):
    def __init__(
        self,
        model: bool = True,
        material: bool = True,
        particle_system: bool = True,
        scene: bool = True,
        world: bool = True,
        geometry_nodes: bool = True,
    ):
        super().__init__("builtin:asset_types")
        self.model = model
        self.material = material
        self.particle_system = particle_system
        self.scene = scene
        self.world = world
        self.geometry_nodes = geometry_nodes

    def filter_(self, asset_: asset.Asset) -> bool:
        type_ = asset_.type_
        return any(
            [
                type_ == asset_data.AssetDataType.blender_model and self.model,
                type_ == asset_data.AssetDataType.blender_material and self.material,
                type_ == asset_data.AssetDataType.blender_particle_system and self.particle_system,
                type_ == asset_data.AssetDataType.blender_scene and self.scene,
                type_ == asset_data.AssetDataType.blender_world and self.world,
                type_ == asset_data.AssetDataType.blender_geometry_nodes and self.geometry_nodes,
            ]
        )

    def as_dict(self) -> dict:
        return {self.name: self._all}

    @property
    def _all(self) -> tuple:
        return (
            self.model,
            self.material,
            self.particle_system,
            self.scene,
            self.world,
            self.geometry_nodes,
        )


SEARCH_ASSET_SCORE: dict[str, float] = {}


class MatchCount(typing.NamedTuple):
    match_count: int
    weight: float


class SearchFilter(Filter):
    def __init__(self, search: str):
        super().__init__("builtin:search")
        self.search = search
        self.needle_keywords = SearchFilter.keywords_from_search(search)

    def filter_(self, asset_: asset.Asset) -> bool:
        REQUIRED_EXACT_MATCH_COEFFICIENT = 10.0
        EXACT_MATCH_COEFFICIENT = 5.0
        PREFIX_MATCH_COEFFICIENT = 3.0
        INFIX_MATCH_COEFFICIENT = 2.0
        SUFFIX_MATCH_COEFFICIENT = 2.0

        MATCH_ORDER_COEFFICIENT = 1.0

        SUBSEQUENT_MATCH_COEFFICIENT = 5.0
        MULTIPLE_MATCH_COEFFICIENT = 1.0

        def get_affix_score(
            needle_keyword: str,
            needle_keyword_index: int,
            haystack_keyword: str,
            haystack_keyword_weight: float,
        ) -> float:
            affix_score = 0.0
            index = haystack_keyword.find(needle_keyword)
            if index == -1:
                # no match
                return affix_score
            if index == 0 and len(haystack_keyword) == len(needle_keyword):
                # bump exact matches even if exact match not requested
                affix_score = EXACT_MATCH_COEFFICIENT * haystack_keyword_weight
            elif index == 0:
                # prefix match
                affix_score = PREFIX_MATCH_COEFFICIENT * haystack_keyword_weight
            elif index < len(haystack_keyword) - len(needle_keyword):
                # infix match
                affix_score = INFIX_MATCH_COEFFICIENT * haystack_keyword_weight
            else:
                # suffix match
                affix_score = SUFFIX_MATCH_COEFFICIENT * haystack_keyword_weight

            if affix_score > 0.0:
                # Boost score based on needle keyword order - earlier keywords are more relevant
                affix_score += (
                    MATCH_ORDER_COEFFICIENT
                    * (len(self.needle_keywords) - needle_keyword_index)
                    / len(self.needle_keywords)
                )
            return affix_score

        def get_multiplicity_score(
            subsequent_match: MatchCount, multiple_match: MatchCount
        ) -> float:
            """Computes multiplicity score based on subsequent and multiple matches.

            The scores take into account both the count and the weight of matches. The weight comes
            from the sum of affix scores meaning exact matches weight more than prefix, etc...
            """
            multiplicity_score = 1.0
            weighted_subsequent_match = subsequent_match.match_count + subsequent_match.weight / 10
            weighted_multiple_match = multiple_match.match_count + multiple_match.weight / 10
            if weighted_subsequent_match <= 1 and weighted_multiple_match <= 1:
                return multiplicity_score
            if weighted_subsequent_match >= weighted_multiple_match:
                multiplicity_score = SUBSEQUENT_MATCH_COEFFICIENT * weighted_subsequent_match
            else:
                multiplicity_score = MULTIPLE_MATCH_COEFFICIENT * weighted_multiple_match
            return multiplicity_score

        def get_exact_match_score(needle_keyword: str, asset_: asset.Asset) -> float:
            haystack_keywords = list(asset_.search_matter.keys())
            needle_keyword_trimmed = needle_keyword[1:-1]
            if needle_keyword_trimmed in haystack_keywords:
                return REQUIRED_EXACT_MATCH_COEFFICIENT

            needle_keywords = needle_keyword_trimmed.split(' ')
            needle_index = next(
                (i for i, kw in enumerate(haystack_keywords) if kw == needle_keywords[0]), -1
            )
            if needle_index == -1:
                return 0.0
            for keyword in needle_keywords[1:]:
                needle_index += 1
                if (
                    needle_index >= len(haystack_keywords)
                    or haystack_keywords[needle_index] != keyword
                ):
                    return 0.0
            return REQUIRED_EXACT_MATCH_COEFFICIENT

        # we make sure all needle keywords are present in given haystack for the haystack not to be
        # filtered

        if len(self.needle_keywords) == 0:
            return True

        max_relevancy_score = 0.0
        # represent (count, weighted_sum) as tuples to keep integer counts pure
        multiple_match = MatchCount(0, 0.0)
        subsequent_match = MatchCount(0, 0.0)
        max_subsequent_match = MatchCount(0, 0.0)

        for i, needle_keyword in enumerate(self.needle_keywords):
            affix_score = 0.0
            match_flag = False
            require_exact_match = needle_keyword.startswith('"') and needle_keyword.endswith('"')

            if require_exact_match:
                exact_match_score = get_exact_match_score(needle_keyword, asset_)
                if exact_match_score == 0.0:
                    # exclude results which do not contain keywords in quotation marks (even if other keywords would match)
                    SEARCH_ASSET_SCORE[asset_.id_] = 0.0
                    return False
                max_relevancy_score = max(max_relevancy_score, exact_match_score)
                match_flag = max_relevancy_score > 0.0
            else:
                for haystack_keyword, haystack_keyword_weight in asset_.search_matter.items():
                    relevancy_score = 0.0
                    # this is guaranteed by the API
                    assert haystack_keyword_weight > 0.0
                    relevancy_score = get_affix_score(
                        needle_keyword,
                        i,
                        haystack_keyword,
                        haystack_keyword_weight,
                    )

                    match_flag = relevancy_score > 0.0 or match_flag
                    affix_score = max(affix_score, relevancy_score)
                    max_relevancy_score = max(max_relevancy_score, relevancy_score)

            if match_flag:
                subsequent_match = MatchCount(
                    subsequent_match.match_count + 1, subsequent_match.weight + affix_score
                )
                multiple_match = MatchCount(
                    multiple_match.match_count + 1, multiple_match.weight + affix_score
                )
                max_subsequent_match = max(
                    max_subsequent_match, subsequent_match, key=lambda x: x.match_count
                )
            else:
                subsequent_match = MatchCount(0, 0.0)

        max_relevancy_score *= get_multiplicity_score(max_subsequent_match, multiple_match)

        SEARCH_ASSET_SCORE[asset_.id_] = max_relevancy_score
        return max_relevancy_score > 0.0

    @staticmethod
    @functools.lru_cache(maxsize=128)
    def keywords_from_search(search: str) -> list[str]:
        """Returns a list of lowercase keywords to search for in the assets"""

        def translate_keywords(keywords: list[str]) -> list[str]:
            # Be careful when adding new keywords as it will make impossible to find anything using the original keyword.
            # E.g. if we'd have tag `hdr` it would not be possible to find it now. Or anything named `hdr_something` cannot be find by `hdr`

            translator = {"hdri": "world", "hdr": "world"}

            ret: list[str] = []
            for kw in keywords:
                ret.append(translator.get(kw, kw))

            return ret

        # put search keywords to a dictionary first to prevent duplicate keywords while keeping the order in which they were searched
        keywords = {kw.lower(): None for kw in re.findall(r'"[^"]*"|\S+', search) if kw != ""}
        return translate_keywords(list(keywords.keys()))

    def as_dict(self) -> dict:
        return {self.name: self.search}
