#!/usr/bin/python3
# copyright (c) 2018- polygoniq xyz s.r.o.

import bpy
import addon_utils
import sys
import os
import pathlib
import typing
import enum
import datetime
import functools
import urllib.request
import urllib.error
import email.utils
import json
import shutil
import subprocess
import math
import time
import re
import logging
import weakref
import threading
import bpy_extras.anim_utils

logger = logging.getLogger(f"polygoniq.{__name__}")


POLYGONIQ_DOCS_URL = "https://docs.polygoniq.com"
POLYGONIQ_GITHUB_REPO_API_URL = "https://api.github.com/repos/polygoniq"

DUPLICATE_SUFFIX_PATTERN = re.compile(r"^\.[0-9]{3}$")


class ByteSizeUnit(enum.IntEnum):
    B = 0
    KiB = 1
    MiB = 2
    GiB = 3
    TiB = 4
    PiB = 5
    EiB = 6
    ZiB = 7
    YiB = 8


def move_file(src: str, dst: str, copy_function=shutil.copyfile):
    """Move file to another location.

    Alternative to `shutil.move` which may use `os.rename` instead of creating an actual copy.
    This is important as `os.rename` will not apply access permissions of the destination to the file.
    """
    copy_function(src, dst)
    os.remove(src)


def autodetect_install_path(
    product: str, init_path: str, install_path_checker: typing.Callable[[str], bool]
) -> str:
    # TODO: We should submit a patch to blender_vscode and deal with this from there in the future
    try:
        vscode_product_path = os.path.expanduser(
            os.path.join("~", "polygoniq", "blender_addons", product)
        )
        try:
            if (
                os.path.commonpath(
                    [os.path.abspath(os.path.realpath(init_path)), vscode_product_path]
                )
                == vscode_product_path
            ):
                staging_path_base = os.path.expanduser(
                    os.path.join("~", "polygoniq", "bazel-bin", "blender_addons", product)
                )
                # Possible sources of built assets from bazel
                FLIP_OF_THE_COIN = [
                    os.path.join(staging_path_base, f"{product}_staging"),
                    os.path.join(staging_path_base, f"data_final"),
                ]
                for flip in FLIP_OF_THE_COIN:
                    if os.path.isdir(flip):
                        print(
                            f"Detected blender_vscode development environment. Going to use {flip} as "
                            f"the install path for {product}."
                        )
                        return flip
        except:
            # not on the same drive
            pass

    except ValueError:  # Paths don't have the same drive
        pass

    big_zip_path = os.path.abspath(os.path.dirname(init_path))
    if install_path_checker(big_zip_path):
        print(f"{product} install dir autodetected as {big_zip_path} (big zip embedded)")
        return big_zip_path

    if sys.platform == "win32":
        SHOTS_IN_THE_DARK = [
            f"C:/{product}",
            f"D:/{product}",
            f"C:/polygoniq/{product}",
            f"D:/polygoniq/{product}",
        ]

        for shot in SHOTS_IN_THE_DARK:
            if install_path_checker(shot):
                print(f"{product} install dir autodetected as {shot}")
                return os.path.abspath(shot)

    elif sys.platform in ["linux", "darwin"]:
        SHOTS_IN_THE_DARK = [
            os.path.expanduser(f"~/{product}"),
            os.path.expanduser(f"~/Desktop/{product}"),
            os.path.expanduser(f"~/Documents/{product}"),
            os.path.expanduser(f"~/Downloads/{product}"),
            os.path.expanduser(f"~/polygoniq/{product}"),
            os.path.expanduser(f"~/Desktop/polygoniq/{product}"),
            os.path.expanduser(f"~/Documents/polygoniq/{product}"),
            os.path.expanduser(f"~/Downloads/polygoniq/{product}"),
            f"/var/lib/{product}",
            f"/usr/local/{product}",
            f"/opt/{product}",
        ]

        for shot in SHOTS_IN_THE_DARK:
            if install_path_checker(shot):
                print(f"{product} install dir autodetected as {shot}")
                return os.path.abspath(shot)

    print(
        f"{product} is not installed in one of the default locations, please make "
        f"sure the path is set in {product} addon preferences!",
        file=sys.stderr,
    )
    return ""


def absolutize_preferences_path(
    self: bpy.types.AddonPreferences, context: bpy.types.Context, path_property_name: str
) -> None:
    assert hasattr(self, path_property_name)
    abs_ = os.path.abspath(getattr(self, path_property_name))
    if abs_ != getattr(self, path_property_name):
        setattr(self, path_property_name, abs_)


def get_user_data_resource_path(addon_name: str, create: bool = False) -> str:
    """Returns the path to the user data resource directory for the given addon name."""
    ret = os.path.join(bpy.utils.user_resource('DATAFILES', create=create), addon_name)
    if create and not os.path.exists(ret):
        os.makedirs(ret)
    return ret


def contains_object_duplicate_suffix(name: str) -> bool:
    return bool(DUPLICATE_SUFFIX_PATTERN.match(name[-4:]))


def remove_object_duplicate_suffix(name: str) -> str:
    splitted_name = name.rsplit(".", 1)
    if len(splitted_name) == 1:
        return splitted_name[0]

    if splitted_name[1].isnumeric():
        return splitted_name[0]

    return name


def generate_unique_name(old_name: str, container: typing.Iterable[typing.Any]) -> str:
    # TODO: Unify this with renderset unique naming generation
    name_without_suffix = remove_object_duplicate_suffix(old_name)
    i = 1
    new_name = name_without_suffix
    while new_name in container:
        new_name = f"{name_without_suffix}.{i:03d}"
        i += 1

    return new_name


def convert_size(size_bytes: int, decimal_places: int = 2, unit: ByteSizeUnit | None = None) -> str:
    """Converts size in bytes to human readable format with an appropriate unit."""

    def format_size(size: float, unit_name: str):
        return f"{size:.{decimal_places}f} {unit_name}"

    if size_bytes == 0:
        return format_size(0, unit.name if unit is not None else ByteSizeUnit.B.name)
    if unit is not None:
        index = unit
    else:
        index = int(math.floor(math.log(size_bytes, 1024)))
    size = round(size_bytes / math.pow(1024, index), decimal_places)
    return format_size(size, ByteSizeUnit(index).name)


def blender_cursor(cursor_name: str = 'WAIT'):
    """Decorator that sets a modal cursor in Blender to whatever the caller desires,
    then sets it back when the function returns. This is useful for long running
    functions or operators. Showing a WAIT cursor makes it less likely that the user
    will think that Blender froze.

    Unfortunately this can only be used in cases we control and only when 'context' is
    available.

    TODO: Maybe we could use bpy.context and drop the context requirement?
    """

    def cursor_decorator(fn):
        @functools.wraps(fn)
        def wrapper(self, context: bpy.types.Context, *args, **kwargs):
            context.window.cursor_modal_set(cursor_name)
            try:
                return fn(self, context, *args, **kwargs)
            finally:
                context.window.cursor_modal_restore()

        return wrapper

    return cursor_decorator


def safe_modal(
    on_exception: typing.Optional[
        typing.Callable[[typing.Any, bpy.types.Context, bpy.types.Event, Exception], typing.Any]
    ] = None,
):
    """Decorator that executes a modal method of modal operator and cancels on exception with a possibility of handling it"""

    def modal_decorator(fn):
        @functools.wraps(fn)
        def wrapper(self, context: bpy.types.Context, event: bpy.types.Event):
            try:
                return fn(self, context, event)
            except Exception as e:
                logger.exception(f"Raised exception in modal operator '{self.__class__.__name__}'")
                if on_exception is not None:
                    return on_exception(self, context, event, e)
                return {'CANCELLED'}

        return wrapper

    return modal_decorator


def timeit(fn):
    @functools.wraps(fn)
    def timed(*args, **kw):
        ts = time.time()
        result = fn(*args, **kw)
        te = time.time()
        print(f"{fn.__name__!r}  {(te - ts) * 1000:2.2f} ms")
        return result

    return timed


def timed_cache(**timedelta_kwargs):
    def _wrapper(f):
        update_delta = datetime.timedelta(**timedelta_kwargs)
        next_update = datetime.datetime.now(datetime.timezone.utc) + update_delta
        f = functools.lru_cache(None)(f)

        @functools.wraps(f)
        def _wrapped(*args, **kwargs):
            nonlocal next_update
            now = datetime.datetime.now(datetime.timezone.utc)
            if now >= next_update:
                f.cache_clear()
                next_update = now + update_delta
            return f(*args, **kwargs)

        setattr(_wrapped, "cache_clear", f.cache_clear)  # mimic lru_cache interface

        return _wrapped

    return _wrapper


TProp = typing.TypeVar('TProp')
TPropReturn = typing.TypeVar('TPropReturn')


class cached_property(typing.Generic[TProp, TPropReturn]):
    """A bpy_types.PropertyGroup-safe cached property.

    This is an (almost) drop-in replacement for functools.cached_property, but it uses
    different caching mechanism that is safe to use with bpy_types.PropertyGroup.

    Functional differences to functools.cached_property:
    - The value will not show up in instance.__dict__
    - To evict a value, use `del instance.property_name` (can't pop it from instance.__dict__)
    - This decorator is thread-safe.
    """

    def __init__(self, func: typing.Callable[[TProp], TPropReturn]) -> None:
        self.func = func
        self.lock = threading.RLock()
        self._cache: weakref.WeakKeyDictionary[TProp, TPropReturn] = weakref.WeakKeyDictionary()

    def __get__(self, instance: TProp | None, _owner: typing.Any = None) -> TPropReturn:
        if instance is None:
            return typing.cast(TPropReturn, self)  # trust me bro

        with self.lock:
            if instance in self._cache:
                return self._cache[instance]

            result = self.func(instance)
            self._cache[instance] = result
            return result

    def __delete__(self, instance: TProp) -> None:
        with self.lock:
            self._cache.pop(instance, None)


def xdg_open_file(path):
    if sys.platform == "win32":
        os.startfile(path)
    elif sys.platform == "darwin":
        subprocess.call(["open", path])
    else:
        subprocess.call(["xdg-open", path])


def fork_running_blender(blend_path: str | None = None) -> None:
    """Opens new instance of Blender which keeps running even if the original instance is closed.

    Opens 'blend_path' if provided, otherwise Blender will open with an empty scene.
    """
    blender_executable = bpy.app.binary_path
    args = [blender_executable]

    if blend_path is not None:
        args += [blend_path]

    if sys.platform in ["win32", "cygwin"]:
        # Detach child process and close its stdin/stdout/stderr, so it can keep running
        # after parent Blender is closed.
        # https://stackoverflow.com/questions/52449997/how-to-detach-python-child-process-on-windows-without-setsid
        flags = 0
        flags |= subprocess.DETACHED_PROCESS
        flags |= subprocess.CREATE_NEW_PROCESS_GROUP
        flags |= subprocess.CREATE_NO_WINDOW
        subprocess.Popen(args, close_fds=True, creationflags=flags)
    elif sys.platform in ["darwin", "linux", "linux2"]:  # POSIX systems
        subprocess.Popen(args, start_new_session=True)
    else:
        raise RuntimeError(f"Unsupported OS: sys.platform={sys.platform}")


def run_logging_subprocess(
    subprocess_args: list[str], logger_: logging.Logger | None = None
) -> int:
    """Runs `subprocess_args` as subprocess and logs stdout and stderr of the subprocess.

    If 'logger_' is None, logger from polib will be used.

    Returns returncode from the subprocess, 0 means that no errors ocurred.
    """
    if logger_ is None:
        logger_ = logger

    process = subprocess.Popen(subprocess_args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

    # Read from indexing process till it's running
    for line in process.stdout:
        logger_.info(line.decode())
    process.wait()
    return process.returncode


def format_signed_int_padding(value: int, padding: int = 4) -> str:
    """Formats signed integer with padding,

    Classic padding treats positive and negative numbers differently,
    e.g. padding 4 will result in:
    -1 -> "-001", 0 -> "0000", 1 -> "0001".

    This function pads positive and negative numbers the same way,
    e.g. -1 -> "-0001", 0 -> "0000", 1 -> "0001".
    """
    return f"{'-' if value < 0 else ''}{abs(value):0{padding}d}"


def filter_invalid_characters_from_path(input_path: str) -> str:
    """Windows, Linux and OSX each have different rules for this. Windows is the most strict
    so we will filter as if the user is always on Windows. This is a design decision but
    assuming people work in heterogenous environments they want to follow rules such that
    everyone can work with all files.

    Caveats:
    Windows has crazy rules, for example folders with the name 'con' are forbidden. We don't
    handle that here because it is extremely difficult to filter that out and there are a ton
    of these exceptions.
    """

    # the overcomplicated typing hint is just so that mypy gets this
    forbidden_chars: dict[str, int | str | None] = {
        "<": "_",
        ">": "_",
        ":": "_",
        "\"": "_",
        "|": "_",
        "?": "_",
        "*": "_",
    }
    # we have to split into drive and path and only replace in the path
    # this prevents replacing the ':' with '_' in e.g. "C:/something"
    drive, path = os.path.splitdrive(input_path)
    return drive + path.translate(str.maketrans(forbidden_chars))


def normalize_path(path: str) -> str:
    """Makes path OS independent."""
    return path.replace("\\", "/")


def get_case_sensitive_path(path: str) -> str:
    """Returns the path with capitalization as it appears on disk.

    Some OSes such as Windows do not consider capitalization while
    resolving paths, while others such as UNIX-based systems do.
    """
    if not os.path.exists(path):
        raise FileNotFoundError(f"File not found: {path}")

    components = pathlib.Path(path).parts

    case_sensitive_path = "."
    if os.path.isabs(path):
        # First component of absolute path is either a drive letter or a `/`, no need to check case
        case_sensitive_path = components[0]
        components = components[1:]

    # Reconstruct the path with case-sensitive names
    for component in components:
        # Check the case of each entry in the directory
        # Using os.path.realpath is not reliable, as it does
        # not return case-sensitive paths for google drive files
        entries = os.listdir(case_sensitive_path)
        # Path may contain current directory or up one level notation, we don't use realpath,
        # because we don't want to change the format of the input path
        entries.extend([".", ".."])
        case_sensitive_entry = None
        for entry in entries:
            # pathlib makes sure correct case-sensitivity is used on every OS
            if pathlib.Path(entry) == pathlib.Path(component):
                case_sensitive_entry = entry
                break
        assert case_sensitive_entry is not None
        case_sensitive_path = os.path.join(case_sensitive_path, case_sensitive_entry)

    return case_sensitive_path


def isfile_case_sensitive(path: str) -> bool:
    """Similar to os.path.isfile, but case sensitive.

    Case sensitive checks are needed on Windows and other case insensitive platforms.
    """
    # fast case insensitive check, filters out folders
    if not os.path.isfile(path):
        return False

    case_sensitive_path = get_case_sensitive_path(path)
    return normalize_path(path) == normalize_path(case_sensitive_path)


def get_bpy_filepath_relative_to_dir(input_dir: str, filepath: str, library=None) -> str:
    file_abspath = bpy.path.abspath(filepath, library=library)
    rel_path = bpy.path.relpath(file_abspath, start=input_dir)
    return normalize_path(rel_path.removeprefix("//"))


def get_first_existing_ancestor_directory(
    file_path: str, whitelist: set[str] | None = None
) -> str | None:
    if whitelist is None:
        whitelist = set()
    if file_path not in whitelist and not os.path.exists(file_path):
        return None
    current_dir = pathlib.Path(os.path.dirname(file_path)).resolve()
    while not os.path.exists(current_dir):
        current_dir = current_dir.parent.resolve()
    return str(current_dir)


def get_all_datablocks(data: bpy.types.BlendData) -> list[tuple[bpy.types.ID, str]]:
    """returns all datablocks and their BlendData type in the currently loaded blend file"""
    # Return a materialized list, don't use generators here, those may result in Blender
    # crashing due to memory issues
    ret = []
    for member_variable_name in dir(data):
        member_variable = getattr(data, member_variable_name)
        if isinstance(member_variable, bpy.types.bpy_prop_collection):
            for datablock in member_variable:
                if isinstance(datablock, bpy.types.ID):
                    ret.append((datablock, member_variable_name))
    return ret


def get_addon_mod_info(module_name: str) -> dict[str, typing.Any]:
    """Returns module bl_info based on its module name."""
    for mod in addon_utils.modules(refresh=False):
        if mod.__name__ == module_name:
            mod_info = addon_utils.module_bl_info(mod)
            return mod_info
    raise ValueError(f"No module '{module_name}' was found!")


def get_release_tag_from_version(version: tuple[int, int, int]) -> str:
    return f"v{'.'.join(map(str, version))}"


def get_conflicting_addons(module_name: str) -> list[str]:
    """Returns a list of messages about possibly conflicting addon installations based on 'module_name'."""
    this_addon_simple_name = module_name.replace("_addon", "")
    if "bl_ext" in this_addon_simple_name:
        # Get the name of the addon if this is an extension module "bl_ext.REPO.ADDON_NAME"
        assert "bl_ext" in this_addon_simple_name
        assert this_addon_simple_name.count(".") >= 2
        this_addon_simple_name = this_addon_simple_name.rsplit(".", 1)[-1]
        # Remove any variant suffixes like _personal, _pro, _studio
        this_addon_simple_name = (
            this_addon_simple_name.replace("_personal", "")
            .replace("_pro", "")
            .replace("_studio", "")
        )

    # Before engon and paq system, each asset pack had its own addon, there was a brief transition period
    # with materialiq 5, when megaddon was what's engon became.
    old_addons = {
        "aquatiq",
        "botaniq",  # also contains "botaniq_evermotion_XX"
        "traffiq",
        "materialiq",
        "megaddon",
    }

    conflicts: list[str] = []

    for mod in addon_utils.modules():
        for candidate in old_addons:
            if candidate in mod.__name__:
                conflicts.append(
                    f"Old polygoniq addon found '{mod.__name__}'. "
                    "This is no longer supported and can cause issues with other addons. "
                    f"Migrate to 'engon' and 'paq' system. More info in documentation."
                )
        if this_addon_simple_name in mod.__name__ and module_name != mod.__name__:
            conflicts.insert(
                0,
                f"Another installation of '{this_addon_simple_name}' found - '{mod.__name__} from {mod.__file__}'! "
                "Keep only one installation please!",
            )

    return conflicts


def get_addon_docs_page(module_name: str) -> str:
    """Returns url of add-on docs based on its module name."""
    mod_info = get_addon_mod_info(module_name)
    # Get only the name without suffix (_full, _lite, etc.)
    name = mod_info["name"].split("_", 1)[0]
    version = ".".join(map(str, mod_info["version"]))
    return f"{POLYGONIQ_DOCS_URL}/{name}/{version}"


def get_addon_release_info(addon_name: str, release_tag: str = "") -> dict[str, typing.Any] | None:
    if release_tag != "":
        url = f"{POLYGONIQ_GITHUB_REPO_API_URL}/{addon_name}/releases/tags/{release_tag}"
    else:
        url = f"{POLYGONIQ_GITHUB_REPO_API_URL}/{addon_name}/releases/latest"
    request = urllib.request.Request(url)
    try:
        response = urllib.request.urlopen(request)
    except (urllib.error.HTTPError, urllib.error.URLError) as e:
        logger.exception(e)
    else:
        result_string = response.read()
        response.close()
        try:
            return json.JSONDecoder().decode(result_string.decode())
        except json.JSONDecodeError as e:
            logger.exception("API response has invalid JSON format")


def get_local_file_last_modified_utc(file_path: str) -> datetime.datetime:
    """Returns the last modified date of a local file."""
    assert os.path.isfile(file_path)
    last_modified_timestamp = os.path.getmtime(file_path)
    return datetime.datetime.fromtimestamp(last_modified_timestamp, tz=datetime.timezone.utc)


def get_remote_file_last_modified_utc(
    url: str,
    timeout: float | None = None,
) -> datetime.datetime | None:
    """Returns the last modified date of a remote file."""
    request = urllib.request.Request(url, method='HEAD')
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            last_modified = response.headers.get('Last-Modified')
            dt = email.utils.parsedate_to_datetime(last_modified)
            if dt is not None:
                return dt.astimezone(datetime.timezone.utc)
            return None
    except (urllib.error.HTTPError, urllib.error.URLError) as e:
        logger.warning(f"Failed to retrieve last modified date of '{url}'. Reason: {e}")
    return None


def get_name_from_blend_path(path: str) -> str:  # folder/structure/name.blend
    asset_name, _ = os.path.splitext(os.path.basename(path))
    return asset_name


def get_nearest_subclass_of(object_: object, type_: type) -> type | None:
    """Returns the nearest subclass of the given type in the MRO of the object's class.

    Example:
        class A
        class B(A)
        class C(B)
        class D(C)

        x = D()

        get_nearest_subclass_of(x, A) = B
        get_nearest_subclass_of(x, B) = C
    """
    for cls in object_.__class__.mro():
        if type_ in cls.__bases__:
            return cls


# Has to be wrapped in a function because collections in bpy.data are not available at the time of
# module import. It results in: "AttributeError: '_RestrictData' object has no attribute 'actions'"
def get_datablock_types_to_collections(
    lib_object: bpy.types.bpy_struct | None = None,
) -> dict[type[bpy.types.ID], bpy.types.bpy_prop_collection]:
    """Returns a mapping of all bpy.types.ID subclasses to their corresponding bpy.data collections.

    Optionally can be used for returning collections from a specific library object.
    Library objects are retrieved when using 'bpy.data.libraries.load'. They are of type 'bpy_lib'
    which is not exposed in bpy.types, so we use 'bpy.types.bpy_struct' as a generic type here.
    """
    # All types that inherit from bpy.types.ID. They're the same in all supported Blenders 3.6 - 4.2
    # If new Blender introduces a new type and we want to support storing it or its properties in
    # renderset context, we have to add it here and handle that it's not present in older Blenders.
    data = bpy.data
    if lib_object is not None:
        data = lib_object

    ret = {
        bpy.types.Action: data.actions,
        bpy.types.Armature: data.armatures,
        bpy.types.Brush: data.brushes,
        bpy.types.CacheFile: data.cache_files,
        bpy.types.Camera: data.cameras,
        bpy.types.Collection: data.collections,
        bpy.types.Curve: data.curves,
        bpy.types.Curves: data.hair_curves,
        bpy.types.FreestyleLineStyle: data.linestyles,
        bpy.types.Image: data.images,
        bpy.types.Lattice: data.lattices,
        bpy.types.Light: data.lights,
        bpy.types.LightProbe: data.lightprobes,
        bpy.types.Mask: data.masks,
        bpy.types.Material: data.materials,
        bpy.types.Mesh: data.meshes,
        bpy.types.MetaBall: data.metaballs,
        bpy.types.MovieClip: data.movieclips,
        bpy.types.NodeTree: data.node_groups,
        bpy.types.Object: data.objects,
        bpy.types.PaintCurve: data.paint_curves,
        bpy.types.Palette: data.palettes,
        bpy.types.ParticleSettings: data.particles,
        bpy.types.PointCloud: data.pointclouds,
        bpy.types.Scene: data.scenes,
        bpy.types.Screen: data.screens,
        bpy.types.Sound: data.sounds,
        bpy.types.Speaker: data.speakers,
        bpy.types.Text: data.texts,
        bpy.types.Texture: data.textures,
        bpy.types.VectorFont: data.fonts,
        bpy.types.Volume: data.volumes,
        bpy.types.WorkSpace: data.workspaces,
        bpy.types.World: data.worlds,
    }

    if bpy.app.version < (5, 0, 0):
        ret[bpy.types.GreasePencil] = data.grease_pencils
    else:
        ret[bpy.types.Annotation] = data.annotations

    if lib_object is None:
        # These collections are not available in library objects
        ret.update(
            {
                bpy.types.Key: data.shape_keys,
                bpy.types.Library: data.libraries,
                bpy.types.WindowManager: data.window_managers,
            }
        )

    return ret


def get_datablock_icon(datablock: bpy.types.ID, default: str = 'FILE_3D') -> str:
    mapping = {
        bpy.types.Action: 'ACTION',
        bpy.types.Armature: 'ARMATURE_DATA',
        bpy.types.Brush: 'BRUSH_DATA',
        bpy.types.CacheFile: 'FILE',
        bpy.types.Camera: 'CAMERA_DATA',
        bpy.types.Collection: 'OUTLINER_COLLECTION',
        bpy.types.Curve: 'CURVE_DATA',
        bpy.types.Curves: 'HAIR',
        bpy.types.FreestyleLineStyle: 'LINE_DATA',
        bpy.types.Image: 'IMAGE_DATA',
        bpy.types.Key: 'SHAPEKEY_DATA',
        bpy.types.Lattice: 'LATTICE_DATA',
        bpy.types.Library: 'LIBRARY_DATA_DIRECT',
        bpy.types.Light: 'LIGHT_DATA',
        bpy.types.LightProbe: 'LIGHTPROBE_CUBEMAP',
        bpy.types.Mask: 'MASK_DATA',
        bpy.types.Material: 'MATERIAL',
        bpy.types.Mesh: 'MESH_DATA',
        bpy.types.MetaBall: 'META_DATA',
        bpy.types.MovieClip: 'CLIP',
        bpy.types.NodeTree: 'NODETREE',
        bpy.types.Object: 'OBJECT_DATA',
        bpy.types.PaintCurve: 'CURVE_BEZCURVE',
        bpy.types.Palette: 'COLOR',
        bpy.types.ParticleSettings: 'PARTICLES',
        bpy.types.PointCloud: 'POINTCLOUD_DATA',
        bpy.types.Scene: 'SCENE_DATA',
        bpy.types.Screen: 'SCREEN_BACK',
        bpy.types.Sound: 'SOUND',
        bpy.types.Speaker: 'SPEAKER',
        bpy.types.Text: 'TEXT',
        bpy.types.Texture: 'TEXTURE',
        bpy.types.VectorFont: 'FONT_DATA',
        bpy.types.Volume: 'VOLUME_DATA',
        bpy.types.WindowManager: 'WINDOW',
        bpy.types.WorkSpace: 'WORKSPACE',
        bpy.types.World: 'WORLD',
    }

    if bpy.app.version < (5, 0, 0):
        mapping[bpy.types.GreasePencil] = 'GREASEPENCIL'
    else:
        mapping[bpy.types.Annotation] = 'GREASEPENCIL'

    # Some datablocks are not direct subclasses of bpy.types.ID
    # and their types are not present on the datablock type to icon map
    return mapping.get(get_nearest_subclass_of(datablock, bpy.types.ID), default)


def get_fcurves_from_action(
    action: bpy.types.Action,
):  # TODO: add retun type hint after dropping Blender < 5.0 support
    """Returns FCurves collection from action.
    This abstracts the difference between Blender versions < 4.4 and >= 4.4.
    Assumes that we want the fcurves from the first slot in Blender >= 4.4.

    Returns `bpy.types.ActionFCruves` in Blender < 4.4
    and `bpy.types.ActionChannelbagFCurves` (or `None` if no animation slot present) in Blender >= 4.4
    """
    if bpy.app.version < (5, 0, 0):
        return action.fcurves
    else:
        if len(action.slots) == 0:
            return None
        channelbag = bpy_extras.anim_utils.action_get_channelbag_for_slot(action, action.slots[0])
        if channelbag is None:
            return None
        return channelbag.fcurves


def is_object_animated(obj: bpy.types.Object) -> bool:
    if obj.animation_data is None or obj.animation_data.action is None:
        return False
    fcurves = get_fcurves_from_action(obj.animation_data.action)
    return fcurves is not None and len(fcurves) > 0
